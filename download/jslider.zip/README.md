# jQuery Slider plugin

jQuery Slider is easy to use and multifunctional jQuery plugin.

[Check out demos and documentations here](http://hmelyoff.github.com/jslider/)

## License

(MIT License) — Copyright &copy; 2012 Egor Khmelev